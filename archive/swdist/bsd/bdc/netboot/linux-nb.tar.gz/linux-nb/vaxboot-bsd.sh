#!/bin/sh
#
# vaxboot-bsd.sh  VAX bootserver components
# Author:         Brian Chase, <bdc@world.std.com>
#

echo "Starting VAX bootserver..."
/usr/local/sbin/areths.csh &
/usr/local/sbin/mopd -a
/usr/local/sbin/bootparamd

exit 0
# end of vaxboot-bsd.sh
