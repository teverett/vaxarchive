#!/bin/sh
#
# vaxboot-sysv.sh  VAX bootserver components
# Author:          Brian Chase, <bdc@world.std.com>
#

# See how we were called.
case "$1" in
  start)
        echo "Starting VAX bootserver..."
        /usr/local/sbin/areths.csh &
        /usr/local/sbin/mopd -a
        /usr/local/sbin/bootparamd
	;;
  stop)
        echo "Shutting down VAX bootserver..."
        /usr/bin/killall bootparamd
        /usr/bin/killall mopd
	;;
  *)
	echo "Usage: $0 {start|stop}"
	exit 1
esac

exit 0
# end of vaxboot-sysv.sh
